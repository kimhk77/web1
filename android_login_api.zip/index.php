Visit the below endpoints<br/>

Login:<br/>
http://YOUR_MACHINE_IP/android_login_api/login.php<br/><br/>

Registration:<br/>
http://YOUR_MACHINE_IP/android_login_api/register.php<br/><br/>

Tutorial link:<br/>
<a href="http://www.androidhive.info/2012/01/android-login-and-registration-with-php-mysql-and-sqlite/">http://www.androidhive.info/2012/01/android-login-and-registration-with-php-mysql-and-sqlite/</a>
